from django.shortcuts import render

# Create your views here.

def home(request):
    return render (request,"home.html")
def style(request):
    return render(request,'style.css')
def index(request):
    return render(request,'index.html')