from django.urls import path
from .views import home
from .views import style
from .views import index

urlpatterns = [
    path ('', home,name="home"),
    path ('',style,name="style"),
    path('',index,name='index'),
]